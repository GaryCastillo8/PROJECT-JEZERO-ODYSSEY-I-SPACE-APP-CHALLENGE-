/* Project Jezero: local-only mission guide interactions. */
(() => {
  "use strict";
  const STORAGE_KEY = "project-jezero-odyssey-i-v1";
  const DAYS = Array.from(
    { length: 9 },
    (_, i) => `DAY ${String(i + 1).padStart(2, "0")}`,
  );
  const MARSWALK = [
    ["Navigation", "nav"],
    ["Terrain Observation", "terrain"],
    ["Environmental Monitoring", "environment"],
    ["Scientific Documentation", "documentation"],
    ["Communication", "communication"],
  ];
  const HAZARDS = [
    "Space Radiation",
    "Isolation and Confinement",
    "Distance from Earth",
    "Altered Gravity Fields",
    "Hostile/Closed Environments",
  ];
  const EMERGENCIES = [
    "Communication interruption",
    "Unexpected environmental changes",
    "Equipment failure",
    "Unexpected obstacles",
    "Radiation alerts",
  ];
  const COMPLETION_ITEMS = [
    "Confirm return",
    "Review scientific data",
    "Report discoveries",
    "Record issues",
    "Complete mission report",
  ];
  const freshState = () => ({
    team: "",
    location: "",
    dayTasks: Object.fromEntries(DAYS.map((day) => [day, []])),
    selectedDay: DAYS[0],
    mapFields: { current: "", route: "", points: "", terrain: "" },
    guidance: {},
    completion: Array(COMPLETION_ITEMS.length).fill(false),
    observations: [],
    references: [],
  });
  let state = loadState();
  let saveTimer;
  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (!saved || typeof saved !== "object") return freshState();
      const base = freshState();
      return {
        ...base,
        ...saved,
        dayTasks: { ...base.dayTasks, ...(saved.dayTasks || {}) },
        mapFields: { ...base.mapFields, ...(saved.mapFields || {}) },
        completion: Array.isArray(saved.completion)
          ? COMPLETION_ITEMS.map((_, i) => !!saved.completion[i])
          : base.completion,
        observations: Array.isArray(saved.observations)
          ? saved.observations
          : [],
        references: Array.isArray(saved.references) ? saved.references : [],
        guidance:
          saved.guidance && typeof saved.guidance === "object"
            ? saved.guidance
            : {},
      };
    } catch (error) {
      console.warn("Saved field guide data could not be read.", error);
      return freshState();
    }
  }
  function saveState(showError = false) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      return true;
    } catch (error) {
      console.error("Local save failed.", error);
      if (showError)
        alert(
          "Browser storage is full or unavailable. Export your records and remove large attachments before continuing.",
        );
      return false;
    }
  }
  const esc = (value) =>
    String(value ?? "").replace(
      /[&<>"']/g,
      (char) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[char],
    );
  const selectedDay = () =>
    DAYS.includes(state.selectedDay) ? state.selectedDay : DAYS[0];
  function dayStats(day) {
    const tasks = state.dayTasks[day] || [];
    const done = tasks.filter((task) => task.done).length;
    return {
      total: tasks.length,
      done,
      percent: tasks.length ? Math.round((done / tasks.length) * 100) : 0,
    };
  }
  function updateMissionProgress() {
    const all = DAYS.reduce(
      (acc, day) => {
        const stats = dayStats(day);
        acc.total += stats.total;
        acc.done += stats.done;
        return acc;
      },
      { total: 0, done: 0 },
    );
    const percent = all.total ? Math.round((all.done / all.total) * 100) : 0;
    document.getElementById("overall-percent").textContent = `${percent}%`;
    document.getElementById("overall-summary").textContent =
      `${all.done} of ${all.total} tasks complete`;
    document.getElementById("overall-fill").style.width = `${percent}%`;
    document
      .querySelector(".overall-track")
      .setAttribute("aria-valuenow", String(percent));
  }
  function renderDays() {
    const tabs = document.getElementById("day-tabs");
    tabs.innerHTML = "";
    DAYS.forEach((day) => {
      const stats = dayStats(day);
      const status =
        stats.total && stats.done === stats.total
          ? "state-done"
          : stats.done > 0
            ? "state-progress"
            : "";
      const button = document.createElement("button");
      button.type = "button";
      button.className = `day-tab ${status}`;
      button.role = "tab";
      button.setAttribute("aria-selected", String(day === selectedDay()));
      button.setAttribute("aria-controls", "day-panel");
      button.innerHTML = `<span>${day}</span><i class="tab-state" aria-hidden="true"></i>`;
      button.addEventListener("click", () => {
        state.selectedDay = day;
        saveState();
        renderDays();
        renderDayPanel();
      });
      tabs.append(button);
    });
    renderDayPanel();
  }
  function renderDayPanel() {
    const day = selectedDay();
    const tasks = state.dayTasks[day] || [];
    const stats = dayStats(day);
    const panel = document.getElementById("day-panel");
    panel.innerHTML = `<div class="day-panel-head"><div><h3>${day} <span style="color:var(--honey)">/</span> Mission checklist</h3><p>Add, edit, or remove tasks according to the approved team plan.</p></div><div class="day-progress"><strong>${stats.percent}%</strong><span>${stats.done} / ${stats.total} TASKS</span><div class="day-progress-track"><i style="width:${stats.percent}%"></i></div></div></div><div class="task-list">${tasks.length ? tasks.map((task, index) => `<div class="task-row ${task.done ? "completed" : ""}" data-task-index="${index}"><input class="task-check" type="checkbox" aria-label="Mark task complete" ${task.done ? "checked" : ""}><input class="task-text" type="text" aria-label="Edit task" value="${esc(task.text)}" placeholder="Enter a team-approved task"><button class="task-remove" type="button" aria-label="Remove task">×</button></div>`).join("") : '<p class="empty-day">No tasks added for this day. Use the field below to add approved tasks.</p>'}</div><form class="task-add" id="task-add-form"><input id="new-task" type="text" maxlength="240" placeholder="Add a mission-approved task…" aria-label="New checklist task"><button class="button primary" type="submit">ADD TASK <span>＋</span></button></form>`;
    panel.querySelectorAll(".task-row").forEach((row) => {
      const index = Number(row.dataset.taskIndex);
      row.querySelector(".task-check").addEventListener("change", (event) => {
        state.dayTasks[day][index].done = event.target.checked;
        saveState();
        renderDays();
        updateMissionProgress();
      });
      row.querySelector(".task-text").addEventListener("input", (event) => {
        state.dayTasks[day][index].text = event.target.value;
        saveState();
      });
      row.querySelector(".task-remove").addEventListener("click", () => {
        state.dayTasks[day].splice(index, 1);
        saveState();
        renderDays();
        updateMissionProgress();
      });
    });
    panel
      .querySelector("#task-add-form")
      .addEventListener("submit", (event) => {
        event.preventDefault();
        const input = panel.querySelector("#new-task");
        const text = input.value.trim();
        if (!text) {
          input.focus();
          return;
        }
        state.dayTasks[day].push({ text, done: false });
        saveState();
        renderDays();
        updateMissionProgress();
        panel.querySelector("#new-task").focus();
      });
  }
  function renderGuidance() {
    const marswalk = document.getElementById("marswalk-list");
    marswalk.innerHTML = "";
    MARSWALK.forEach(([title, key], index) => {
      const item = document.createElement("div");
      item.className = "accordion-item";
      item.innerHTML = `<button class="accordion-trigger" type="button" aria-expanded="false"><span class="accordion-num">0${index + 1}</span><strong>${title}</strong><small>TEAM-APPROVED GUIDANCE</small><span class="accordion-plus" aria-hidden="true">＋</span></button><div class="accordion-body" hidden><label>${title} guidance<textarea data-guidance="procedure:${key}" rows="3" placeholder="Add mission-approved ${title.toLowerCase()} instructions.">${esc(state.guidance[`procedure:${key}`] || "")}</textarea></label></div>`;
      item.querySelector("button").addEventListener("click", (event) => {
        const button = event.currentTarget;
        const open = button.getAttribute("aria-expanded") === "true";
        button.setAttribute("aria-expanded", String(!open));
        item.querySelector(".accordion-body").hidden = open;
      });
      item.querySelector("textarea").addEventListener("input", (event) => {
        state.guidance[event.target.dataset.guidance] = event.target.value;
        saveState();
      });
      marswalk.append(item);
    });
    const safety = document.getElementById("safety-grid");
    safety.innerHTML = "";
    HAZARDS.forEach((title, index) => {
      const key = `safety:${index}`;
      const card = document.createElement("article");
      card.className = "safety-card";
      card.innerHTML = `<span class="safety-index">H-${String(index + 1).padStart(2, "0")}</span><h3>${title}</h3><textarea data-guidance="${key}" rows="3" placeholder="Add team-reviewed guidance and references.">${esc(state.guidance[key] || "")}</textarea>`;
      card.querySelector("textarea").addEventListener("input", (event) => {
        state.guidance[key] = event.target.value;
        saveState();
      });
      safety.append(card);
    });
    const emergency = document.getElementById("emergency-grid");
    emergency.innerHTML = "";
    EMERGENCIES.forEach((title, index) => {
      const key = `emergency:${index}`;
      const card = document.createElement("article");
      card.className = "emergency-card";
      card.innerHTML = `<span>CONTINGENCY 0${index + 1}</span><h3>${title}</h3><textarea data-guidance="${key}" rows="2" placeholder="Insert approved procedure; do not use until validated.">${esc(state.guidance[key] || "")}</textarea>`;
      card.querySelector("textarea").addEventListener("input", (event) => {
        state.guidance[key] = event.target.value;
        saveState();
      });
      emergency.append(card);
    });
  }
  function renderCompletion() {
    const root = document.getElementById("completion-list");
    root.innerHTML = "";
    COMPLETION_ITEMS.forEach((label, index) => {
      const row = document.createElement("label");
      row.className = `completion-row ${state.completion[index] ? "done" : ""}`;
      row.innerHTML = `<input type="checkbox" ${state.completion[index] ? "checked" : ""}><span>${label}</span>`;
      row.querySelector("input").addEventListener("change", (event) => {
        state.completion[index] = event.target.checked;
        saveState();
        renderCompletion();
      });
      root.append(row);
    });
    const percent = Math.round(
      (state.completion.filter(Boolean).length / COMPLETION_ITEMS.length) * 100,
    );
    document.getElementById("completion-percent").textContent = `${percent}%`;
  }
  function renderObservations() {
    const root = document.getElementById("observation-list");
    const count = state.observations.length;
    document.getElementById("observation-count").textContent =
      `${count} ${count === 1 ? "ENTRY" : "ENTRIES"}`;
    if (!count) {
      root.innerHTML =
        '<div class="empty-observations"><span>— —</span><p>No observations recorded.<br>Saved entries will appear here.</p></div>';
      return;
    }
    root.innerHTML = "";
    state.observations.forEach((entry, index) => {
      const article = document.createElement("article");
      article.className = "observation-entry";
      const content = document.createElement("div");
      const title = document.createElement("h4");
      title.textContent =
        entry.id || `Observation ${String(index + 1).padStart(2, "0")}`;
      content.append(title);
      const details = [
        entry.type,
        entry.location,
        entry.datetime,
        entry.description,
      ]
        .filter(Boolean)
        .join(" · ");
      if (details) {
        const p = document.createElement("p");
        p.textContent = details;
        content.append(p);
      }
      if (entry.imageData) {
        const img = document.createElement("img");
        img.src = entry.imageData;
        img.alt = entry.imageName
          ? `Attachment: ${entry.imageName}`
          : "Observation attachment";
        content.append(img);
      }
      const remove = document.createElement("button");
      remove.type = "button";
      remove.setAttribute("aria-label", "Delete observation");
      remove.textContent = "×";
      remove.addEventListener("click", () => {
        state.observations.splice(index, 1);
        saveState();
        renderObservations();
      });
      article.append(content, remove);
      root.append(article);
    });
  }
  function renderReferences() {
    const root = document.getElementById("reference-list");
    root.innerHTML = "";
    if (!state.references.length) {
      root.innerHTML =
        '<p class="reference-empty">No references added yet.</p>';
      return;
    }
    state.references.forEach((ref, index) => {
      const row = document.createElement("div");
      row.className = "reference-item";
      const link = document.createElement("a");
      link.href = ref.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = ref.title;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.setAttribute("aria-label", "Remove reference");
      remove.textContent = "×";
      remove.addEventListener("click", () => {
        state.references.splice(index, 1);
        saveState();
        renderReferences();
      });
      row.append(link, remove);
      root.append(row);
    });
  }
  function init() {
    document.getElementById("team-name").value = state.team || "";
    document.getElementById("exploration-location").value =
      state.location || "";
    document.getElementById("team-name").addEventListener("input", (event) => {
      state.team = event.target.value;
      saveState();
    });
    document
      .getElementById("exploration-location")
      .addEventListener("input", (event) => {
        state.location = event.target.value;
        saveState();
      });
    document.querySelectorAll("[data-map-field]").forEach((input) => {
      input.value = state.mapFields[input.dataset.mapField] || "";
      input.addEventListener("input", (event) => {
        state.mapFields[event.target.dataset.mapField] = event.target.value;
        saveState();
      });
    });
    renderDays();
    renderGuidance();
    renderCompletion();
    renderObservations();
    renderReferences();
    updateMissionProgress();
    document
      .getElementById("observation-form")
      .addEventListener("submit", addObservation);
    document
      .getElementById("export-observations")
      .addEventListener("click", exportObservations);
    document
      .getElementById("reference-form")
      .addEventListener("submit", addReference);
    const menu = document.getElementById("side-nav"),
      toggle = document.getElementById("menu-toggle");
    toggle.addEventListener("click", () => {
      const open = menu.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    menu.querySelectorAll(".nav-link").forEach((link) =>
      link.addEventListener("click", () => {
        menu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      }),
    );
    const sections = [...document.querySelectorAll("main section[id]")];
    if ("IntersectionObserver" in window) {
      const observer = new IntersectionObserver(
        (entries) =>
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              document
                .querySelectorAll(".nav-link")
                .forEach((link) =>
                  link.classList.toggle(
                    "active",
                    link.getAttribute("href") === `#${entry.target.id}`,
                  ),
                );
            }
          }),
        { rootMargin: "-20% 0px -70% 0px" },
      );
      sections.forEach((section) => observer.observe(section));
    }
  }
  async function addObservation(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const file = data.get("image");
    let imageData = "";
    const feedback = document.getElementById("form-feedback");
    feedback.textContent = "";
    if (file && file.size) {
      if (!file.type.startsWith("image/")) {
        feedback.textContent = "Choose an image file.";
        return;
      }
      try {
        imageData = await compressImage(file);
      } catch (error) {
        feedback.textContent = "Could not read that image.";
        return;
      }
    }
    const entry = {
      id: data.get("id").trim(),
      type: data.get("type").trim(),
      location: data.get("location").trim(),
      datetime: data.get("datetime"),
      description: data.get("description").trim(),
      imageName: file && file.size ? file.name : "",
      imageData,
      createdAt: new Date().toISOString(),
    };
    if (
      !Object.values(entry).some(
        (value) => typeof value === "string" && value.trim(),
      )
    ) {
      feedback.textContent = "Enter at least one observation detail.";
      return;
    }
    state.observations.unshift(entry);
    if (!saveState()) {
      state.observations.shift();
      feedback.textContent = "Save failed — browser storage may be full.";
      return;
    }
    form.reset();
    feedback.textContent = "Saved locally.";
    renderObservations();
  }
  function compressImage(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = () => {
        const image = new Image();
        image.onerror = reject;
        image.onload = () => {
          const scale = Math.min(1, 1400 / Math.max(image.width, image.height));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(image.width * scale));
          canvas.height = Math.max(1, Math.round(image.height * scale));
          canvas
            .getContext("2d")
            .drawImage(image, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL("image/jpeg", 0.78));
        };
        image.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }
  function exportObservations() {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            mission: "PROJECT JEZERO: ODYSSEY I",
            exportedAt: new Date().toISOString(),
            observations: state.observations,
          },
          null,
          2,
        ),
      ],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "project-jezero-observations.json";
    link.click();
    URL.revokeObjectURL(url);
  }
  function addReference(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const title = form.elements.title.value.trim();
    let url;
    try {
      url = new URL(form.elements.url.value.trim());
    } catch {
      return;
    }
    if (!["http:", "https:"].includes(url.protocol)) return;
    state.references.push({ title, url: url.href });
    saveState();
    form.reset();
    renderReferences();
  }
  init();
})();
